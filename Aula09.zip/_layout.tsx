import { Drawer } from 'expo-router/drawer';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function Layout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <Drawer
        screenOptions={{
          headerStyle: { backgroundColor: '#6200ee' },
          headerTintColor: '#fff',
          drawerActiveTintColor: '#6200ee',
        }}
      >
        <Drawer.Screen
          name="index"
          options={{
            drawerLabel: 'Início',
            title: 'Início',
          }}
        />

        <Drawer.Screen
          name="autores"
          options={{
            drawerLabel: 'Autores',
            title: 'Autores deste app',
          }}
        />

        <Drawer.Screen
          name="cubo"
          options={{
            drawerLabel: 'Cubo',
            title: 'Calculando o Cubo',
          }}
        />
        
        <Drawer.Screen
          name="settings"
          options={{
            drawerLabel: 'Configurações',
            title: 'Configurações',
          }}
        />

        <Drawer.Screen
          name="explore"
          options={{
            drawerItemStyle: { display: 'none' },
          }}
        />
      </Drawer>
    </GestureHandlerRootView>
  );
}
