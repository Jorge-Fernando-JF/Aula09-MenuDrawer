import { StyleSheet, Text, View } from 'react-native';

export default function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚙️ Configurações</Text>
      <Text style={styles.textogeral}>
        Ajuste suas preferências. Esta opção está no arquivo settings.tsx e está pendente de implementação.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 80, // Espaçamento para o título não colar na barra superior
    paddingHorizontal: 25,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a1a2e',
    marginBottom: 30,
    textAlign: 'center',
  },
  textogeral: {
    fontSize: 16,
    color: '#333',
    textAlign: 'justify',
    lineHeight: 24,
  },
});
