import { Image, StyleSheet, Text, View } from 'react-native';

export default function ProfileScreen() {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.container}>
        <Text style={styles.title}>👤 Autores deste app</Text>
        <View style={styles.imageWrapper}>
          <Image
            source={{ uri: 'https://conteudo.imguol.com.br/c/esporte/12/2026/03/15/memphis-depay-em-acao-pelo-corinthians-em-classico-contra-o-santos-no-brasileirao-1773607549814_v2_450x450.jpg' }}
            style={styles.avatar}
            accessibilityLabel={'Foto dos autores principais'}
          />
          <Image
            source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsclaCZ5aQhLF8_XFI6hIF-Fv6FiMeR8rikn95WlHzyCBQ2rS79QYV16A&s=10' }}
            style={styles.avatar}
            accessibilityLabel={'Foto dos autores principais'}
          />
          <Image
            source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT25rn1UXGmz4aBjUJa_xIw_D6XoSRkVp71wkkWm7Sjw0Y7h5ynPSP2mszU&s=10' }}
            style={styles.avatar}
            accessibilityLabel={'Foto dos autores principais'}
          />
        </View>
        <Text style={styles.subtitle}>Alunos (exemplo):</Text>
        <Text style={styles.textaluno}>Jorge Fernando</Text>
        <Text style={styles.textaluno}>Pedro Henrique Alves Pereira</Text>
        <Text style={styles.textaluno}>Guilherme Marques</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  cardContainer: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 25,
    width: '90%',
    maxWidth: 340,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1a1a2e',
    marginBottom: 20,
    textAlign: 'center',
  },
  imageWrapper: {
    flexDirection: 'row',
    backgroundColor: '#e3f2fd', // Fundo esverdeado/azulado claro das fotos
    padding: 10,
    borderRadius: 12,
    marginBottom: 25,
    gap: 12,
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: 8,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 15,
    textAlign: 'center',
  },
  textaluno: {
    fontSize: 14,
    color: '#555',
    lineHeight: 22,
    textAlign: 'center',
  },
});
