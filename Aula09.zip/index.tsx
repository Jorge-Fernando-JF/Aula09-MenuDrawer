import { StyleSheet, Text, View } from 'react-native';

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>🏠 Tela Início</Text>
      <Text style={styles.textogeral}>
        Bem-vindo a um exemplo de app com Expo Router, que utiliza um menu de tipo 'hambúrguer'.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 80, // Mantém o mesmo padrão de altura da tela de configurações
    paddingHorizontal: 25,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a1a2e',
    marginBottom: 30,
    textAlign: 'center',
  },
  textogeral: {
    fontSize: 16,
    color: '#333',
    textAlign: 'justify',
    lineHeight: 24,
  },
});
