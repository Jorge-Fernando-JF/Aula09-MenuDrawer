import React from 'react';
import { Alert, Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default class App extends React.Component {
  state = {
    valor: '',
    resultado: null
  };

  calcularCubo = () => {
    const num = parseFloat(this.state.valor);
    if (isNaN(num)) {
      Alert.alert("Erro", "Por favor, digite um número válido");
    } else {
      this.setState({ resultado: num * num * num });
    }
  };

  render() {
    return (
      <View style={styles.container1}>
        <Text style={styles.textTitulo}>Cubo de um valor</Text>
        
        <Image
          source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3bbcM2PR5bdOQAfDiZMxrOk6T5M4s8Fsk-pLTNvw_fPwWFz5zIvFoN2olYsmi4DhQAiBEiL2rnCi2Nqa0aDefkak_EF9aAyuoWjqpyKA&s=10' }}
          style={styles.figuraFormato}
          resizeMode="cover"
        />

        <View style={styles.row}>
          <Text style={styles.label}>Digite um valor:</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            onChangeText={(text) => this.setState({ valor: text })}
            value={this.state.valor}
          />
        </View>

        <TouchableOpacity style={styles.button} onPress={this.calcularCubo}>
          <Text style={styles.buttonText}>Calcular Cubo</Text>
        </TouchableOpacity>

        {this.state.resultado !== null && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Resultado: {this.state.resultado}</Text>
          </View>
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container1: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  textTitulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2f3640',
    marginBottom: 20,
  },
  figuraFormato: {
    width: 250,
    height: 150,
    borderRadius: 8,
    marginBottom: 30,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
  },
  label: {
    fontSize: 16,
    color: '#7f8c8d',
    marginRight: 10,
  },
  input: {
    width: 80,
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
  button: {
    backgroundColor: '#574bfc',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    marginBottom: 25,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    backgroundColor: '#fff',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eaeaea',
  },
  resultText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#574bfc',
  },
});
